class Main {
    public static void main(String [] args) {
        System.out.println("Able was I sae Elba");
    }
}
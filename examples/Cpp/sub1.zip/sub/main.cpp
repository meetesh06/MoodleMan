#include <iostream>
int main() {
    std::cout << "This is a Cpp project" << std::endl;
}
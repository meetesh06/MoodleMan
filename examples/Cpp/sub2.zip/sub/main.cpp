#include <iostream>
int main() {
    std::cout << "This is a Cpp projext" << std::endl;
}